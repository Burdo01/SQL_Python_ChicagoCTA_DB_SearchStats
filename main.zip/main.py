#
# SQL_CTA_DB_SearchCommands, Brett Arnold
# Program searches and compiles different stats 
# from Chicago CTA database using SQL and written in python

import sqlite3
import matplotlib.pyplot as plt
import sys 


##################################################################  
#
# print_stats
#
# Given a connection to the CTA database, executes various
# SQL queries to retrieve and output basic stats.
#
def print_stats(dbConn):
    #open connection to cursor
    dbCursor = dbConn.cursor()
    #general stats
    print("General stats:")
    #1:
    dbCursor.execute("Select count(*) From Stations;")
    row = dbCursor.fetchone();
    print("  # of stations:", f"{row[0]:,}")
    #2:
    dbCursor.execute("Select count(Stop_Name) From Stops;")
    row = dbCursor.fetchone();
    print("  # of stops:", f"{row[0]:,}")
    #3:
    dbCursor.execute("Select count(Num_Riders) From Ridership;")
    row = dbCursor.fetchone();
    print("  # of ride entries:", f"{row[0]:,}")
    #4:
    sql = """Select Date(Ride_Date) as date From Ridership
            group by date order by date asc;"""
    dbCursor.execute(sql);
    rows = dbCursor.fetchall();
    print("  date range:", rows[0][-1], "-", rows[-1][0])
    #5:
    dbCursor.execute("Select sum(Num_Riders) From Ridership;")
    row = dbCursor.fetchone();
    print("  Total ridership:", f"{row[0]:,}")
    #6:
    sql = """Select sum(Num_Riders) From Ridership
             where Type_of_Day = 'W';"""
    dbCursor.execute(sql)
    row2 = dbCursor.fetchone();
    print("  Weekday ridership:", f"{row2[0]:,}", '({:.2f}%)'.format((row2[0]/row[0]) * 100))
    #7:
    sql = """Select sum(Num_Riders) From Ridership
             where Type_of_Day = 'A';"""
    dbCursor.execute(sql)
    row3 = dbCursor.fetchone();
    print("  Saturday ridership:", f"{row3[0]:,}", '({:.2f}%)'.format((row3[0]/row[0]) * 100))
    #8
    sql = """Select sum(Num_Riders) From Ridership
             where Type_of_Day = 'U';"""
    dbCursor.execute(sql)
    row4 = dbCursor.fetchone();
    print("  Sunday/holiday ridership:", f"{row4[0]:,}", '({:.2f}%)'.format((row4[0]/row[0]) * 100))
    #close cursor
    dbCursor.close()
    
    #shows station ids and names in asc order via variable station name
def command1(dbConn):
    
    dbCursor = dbConn.cursor()

    name = input("\nEnter partial station name (wildcards _ and %): ")
    
    sql = """Select Station_ID, (Station_Name)
             From Stations
             Where Station_Name like ?
             Order By Station_Name asc;"""
             
    dbCursor.execute(sql, [name] )
    rows = dbCursor.fetchall()
    
    if len(rows) == 0:
        print("**No stations found...")
        user_control(dbConn)
    else: 
        for row in rows: 
            print(row[0], ":", row[1])
        
    dbCursor.close()
    
    user_control(dbConn)
    
    
    #shows sum of all riders per station grouped by asc name
def command2(dbConn):
    
    dbCursor = dbConn.cursor()
    
    print("** ridership all stations **")
    
    sql = """Select Station_Name, sum(Num_Riders)
             From Stations
             join Ridership on Ridership.Station_ID = Stations.Station_ID
             group by Station_Name
             Order By Station_Name asc;"""
             
    dbCursor.execute(sql)
    rows = dbCursor.fetchall()
    
    dbCursor.execute("Select sum(Num_Riders) From Ridership;")
    rowTotal = dbCursor.fetchone();
    
    if len(rows) == 0:
        print("\n**No stations found...")
    
    for row in rows:
        print(row[0], ":", f"{row[1]:,}", '({:.2f}%)'.format((row[1]/rowTotal[0]) * 100))
        
    dbCursor.close()
    
    user_control(dbConn)
    
 
  # shows top 10 frequented stations  
def command3(dbConn):
    
    dbCursor = dbConn.cursor()
    
    print("** top-10 stations **")
    
    sql = """Select Station_Name, sum(Num_Riders)
             From Stations
             join Ridership on Ridership.Station_ID = Stations.Station_ID
             group by Station_Name
             Order By sum(Num_Riders) desc
             limit 10;"""
             
    dbCursor.execute(sql)
    rows = dbCursor.fetchall()
    
    dbCursor.execute("Select sum(Num_Riders) From Ridership;")
    rowTotal = dbCursor.fetchone();
    
    if len(rows) == 0:
        print("**No stations found...")
    
    for row in rows:
        print(row[0], ":", f"{row[1]:,}", '({:.2f}%)'.format((row[1]/rowTotal[0]) * 100))
        
    dbCursor.close()
    
    user_control(dbConn)
    
    # shows least 10 frequented stations
def command4(dbConn):
    
    dbCursor = dbConn.cursor()
    
    print("** least-10 stations **")
    
    sql = """Select Station_Name, sum(Num_Riders)
             From Stations
             join Ridership on Ridership.Station_ID = Stations.Station_ID
             group by Station_Name
             Order By sum(Num_Riders) asc
             limit 10;"""
             
    dbCursor.execute(sql)
    rows = dbCursor.fetchall()
    
    dbCursor.execute("Select sum(Num_Riders) From Ridership;")
    rowTotal = dbCursor.fetchone();
    
    if len(rows) == 0:
        print("**No stations found...")
    
    for row in rows:
        print(row[0], ":", f"{row[1]:,}", '({:.2f}%)'.format((row[1]/rowTotal[0]) * 100))
        
    dbCursor.close()
    
    user_control(dbConn)
    
    
    #retrieves stop information via variable line color 
def command5(dbConn):
    
    
    dbCursor = dbConn.cursor()
    
    color = input("\nEnter a line color (e.g. Red or Yellow): ")
    
    sql = """Select Stop_Name, Direction, ADA, Color
             From Lines
             join StopDetails on Lines.Line_ID = StopDetails.Line_ID
             join Stops on StopDetails.Stop_ID = Stops.Stop_ID
             Where Color like ?
             Order By Stop_Name asc;"""
             
    dbCursor.execute(sql, [color] )
    rows = dbCursor.fetchall()
    
    if len(rows) == 0:
        print("**No such line...")
    
    for row in rows:
        print(row[0], ":", "direction = ", row[1], "(accessible?", end = ' ')
        if row[2] == 1: 
            print("yes)") 
        else: 
            print("no)")
        
    dbCursor.close()
    
    user_control(dbConn)
    
    
  #retrieves number of riders at stations per month and plots  
def command6(dbConn):
    
    dbCursor = dbConn.cursor()

    print("** ridership by month **")
    
    sql = """Select strftime('%m', Ride_Date), sum(Num_Riders)
             From Ridership
             group by strftime('%m', Ride_Date)
             Order By strftime('%m', Ride_Date) asc;"""
             
    dbCursor.execute(sql)
    rows = dbCursor.fetchall()
    
    for row in rows:
        print(row[0], ":", f"{row[1]:,}")
    #plot      
    query = input("\nPlot? (y/n) ")
    
    if query == 'y':
        x = []
        y = []
        for row in rows:
            x.append(row[0])
            y.append(row[1])
        plt.xlabel("month")
        plt.ylabel("number of riders (x * 10^8)")
        plt.title("monthly ridership")
    
        plt.plot(x,y)
        plt.show()
        
    else:
        user_control(dbConn)
        
        
    dbCursor.close()
    
    user_control(dbConn)
    
    
  # yearly number of riders and year with plot  
def command7(dbConn):
    
    dbCursor = dbConn.cursor()
    #query
    print("** ridership by year **")
    
    sql = """Select strftime('%Y', Ride_Date), sum(Num_Riders)
             From Ridership
             group by strftime('%Y', Ride_Date)
             Order By strftime('%Y', Ride_Date) asc;"""
             
    dbCursor.execute(sql)
    rows = dbCursor.fetchall()
    
    for row in rows:
        print(row[0], ":", f"{row[1]:,}")
     #plot   
    query = input("\nPlot? (y/n) ")
    
    if query == 'y':
        x = []
        y = []
        for row in rows:
            x.append(row[0])
            y.append(row[1])
        plt.xlabel("year")
        plt.ylabel("number of riders (x * 10^8)")
        plt.title("yearly ridership")
    
        plt.plot(x,y)
        plt.show()
    else:
        user_control(dbConn)
        
        
    dbCursor.close()
    
    user_control(dbConn)
    
 #command compares first 5 and last 5 riders per day on variable station and year with plot
def command8(dbConn):
    
    dbCursor = dbConn.cursor()
    year = input("\nYear to compare against? ")
    #station1 check query  
    station1 = input("\nEnter station 1 (wildcards _ and %): ")
    
    sqln= """Select count(distinct(Ridership.Station_ID))
             From Ridership
             join Stations on Ridership.Station_ID = Stations.Station_ID
             where strftime('%Y', Ride_Date) = ? and Station_Name like ?;"""       
    dbCursor.execute(sqln, [year, station1])
    rowsn = dbCursor.fetchall()
    #check1
    if rowsn[0][0] > 1:
        print("**Multiple stations found...")
        return user_control(dbConn)
    elif rowsn[0][0] == 0:
        print("**No station found...")
        return user_control(dbConn)         
    #station1 query      
    sql = """Select Date(Ride_Date), Ridership.Station_ID, Num_Riders, Station_Name, strftime('%j', Ride_Date) - 1, count(Ridership.Station_ID), count(Num_Riders)
             From Ridership
             join Stations on Ridership.Station_ID = Stations.Station_ID
             where strftime('%Y', Ride_Date) = ? and Station_Name like ?
             group by Ride_Date
             order by Ride_Date;"""
    dbCursor.execute(sql, [year, station1])
    rows1 = dbCursor.fetchall()

    #station2 check/ user input
    station2 = input("\n\nEnter station 2 (wildcards _ and %): ") 
    dbCursor.execute(sqln, [year, station2])
    rowsn = dbCursor.fetchall()
    if rowsn[0][0] > 1:
        print("**Multiple stations found...")
        return user_control(dbConn)
    elif rowsn[0][0] == 0:
        print("**No station found...")
        return user_control(dbConn)
    #station2 query
    dbCursor.execute(sql, [year, station2])
    rows2 = dbCursor.fetchall()       
    #station1 output         
    print("Station 1:", rows1[0][1], rows1[0][3])
    for row in rows1[0:5]:
        print(row[0], row[2])
    for row in rows1[len(rows1) - 5: len(rows1)]:
        print(row[0], row[2])   
    #station2 output
    print("Station 2:", rows2[0][1], rows2[0][3])
    for row in rows2[0:5]:
        print(row[0], row[2])

    for row in rows2[len(rows2) - 5: len(rows2)]:
        print(row[0], row[2]) 
    #plot 
    query = input("\nPlot? (y/n) ")
    
    if query == 'y':
        x1 = []
        y1 = []
        x2 = []
        y2 = []
        for row1 in rows1:
            x1.append(row1[4])
            y1.append(row1[2])
        for row2 in rows2:
             x2.append(row2[4])
             y2.append(row2[2])
             
        plt.xlabel("day")
        plt.ylabel("number of riders")
        plt.title("riders each day of 2020")
        plt.xticks([0, 50, 100, 150, 200, 250, 300, 350])
    
        plt.plot(x1,y1, label = rows1[0][3])
        plt.plot(x2,y2, label = rows2[0][3])
        plt.legend()
        plt.show()
    else:
        user_control(dbConn) 
        
    dbCursor.close()
    user_control(dbConn)
    
  
   #command retrieves SationName and coordinates with mapped plot
def command9(dbConn):
    
    dbCursor = dbConn.cursor()
    
    color = input("\nEnter a line color (e.g. Red or Yellow): ")
    
    sql = """Select Color, Station_Name, Longitude, Latitude
             from Lines
             join StopDetails on Lines.Line_ID = StopDetails.Line_ID
             join Stops on StopDetails.Stop_ID = Stops.Stop_ID
             join Stations on Stops.Station_ID = Stations.Station_ID
             where Color like ?
             group by Color, Station_Name
             Order By Station_Name asc;"""
             
    dbCursor.execute(sql, [color])
    rows = dbCursor.fetchall()
    
    if len(rows) == 0:
        print("**No such line...")
        return user_control(dbConn)
    
    for row in rows:
        print(row[1], ":", f"({row[3]:,},", f"{row[2]:,})" )
        
    query = input("\nPlot? (y/n) ")
    
    #plotting data
    if query == 'y':
        x = []
        y = []
    
    
        image = plt.imread("chicag0.png")
        xydims = [-87.9277, -87.5569, 41.7012, 42.0868] # area covered by the map:
        plt.imshow(image, extent=xydims)
    
        plt.title(color + " line")
    
        if (color.lower() == "purple-express"):
            color="Purple" # color="#800080"

        # annotated for each (x, y) coordinate with its station name:
        for row in rows:
            x.append(row[3])
            y.append(row[2])
            plt.annotate(row[1], (row[2], row[3]))

        plt.plot(x, y, "o", c = color)
        plt.xlim([-87.9277, -87.5569])
        plt.ylim([41.7012, 42.0868])
        plt.show()
        
    else:
        user_control(dbConn)  
      
        
    dbCursor.close()
    user_control(dbConn)
    
        
        
    
  #main user interface  
def user_control(dbConn):
    #user input
    val = input("\nPlease enter a command (1-9, x to exit): ")
    
    # user control menu
    if val == 'x':
        sys.exit()
        
    elif val == '1': 
        return command1(dbConn)
        
    elif val == '2':
            return command2(dbConn);
        
    elif val == '3':
            return command3(dbConn);
        
    elif val == '4':
            return command4(dbConn);
        
    elif val == '5':
            return command5(dbConn);
        
    elif val == '6':
            return command6(dbConn);
        
    elif val == '7':
            return command7(dbConn);
        
    elif val == '8':
            return command8(dbConn);
        
    elif val == '9':
        return command9(dbConn);
    else:
        print("**Error, unknown command, try again...")
        user_control(dbConn)
        
    

##################################################################  
#
# main
#
print('** Welcome to CTA L analysis app **')
print()

dbConn = sqlite3.connect('CTA2_L_daily_ridership.db')

print_stats(dbConn) #prints general stats
user_control(dbConn) #calls user control menu

#
# done
#
